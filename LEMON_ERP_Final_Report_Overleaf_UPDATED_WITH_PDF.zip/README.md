# LEMON/MELON ERP Final LaTeX Report

This folder is Overleaf-ready.

## Main file

- `main.tex`

## Recommended compiler

- pdfLaTeX

## What is included

- Updated final ERP report with subject-level statistics
- W4/W5 sensitivity interpretation
- Publication-ready ERP figures from `reports/final_figures_v2`
- CSV tables used to support the report

## Main figures used in the report

- `figures/figure_01_difference_waves_v2.png`
- `figures/figure_02_w4_subject_boxplot_compact_v2.png`
- `figures/figure_03_w4_w5_summary_v2.png`
- `figures/figure_05_w4_minus_w5_boxplot_v2.png`

## Supplementary figures

- `figures/figure_02b_w4_subject_boxplot_all_v2.png`
- `figures/figure_04_w4_w5_paired_subjects_compact_v2.png`

## Scientific framing

This report does not claim participant-level emotion recognition. The current interpretation is that the LEMON/MELON Emotional Affect paradigm supports stimulus-locked face-related ERP analysis. Face--Non-face effects are stronger and more stable than Emotional--Neutral effects. Ear-EEG partially preserves the late Face--Non-face response, especially in strict-ear and right-ear ROIs.
